
export enum Language {
  ENGLISH = 'English',
  HINDI = 'हिन्दी',
  MARATHI = 'मराठी',
}

export enum View {
  ADVISOR = 'ADVISOR',
  GENERATOR = 'GENERATOR',
  SCANNER = 'SCANNER',
  AWARENESS = 'AWARENESS',
}

export interface ChatMessage {
  role: 'user' | 'model';
  content: string;
}
