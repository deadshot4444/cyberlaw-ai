import { GoogleGenAI, Chat, GenerateContentResponse } from "@google/genai";
import { Language } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable is not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const getSystemInstruction = (language: Language): string => {
    return `You are an expert legal advisor named "CyberGuard" specializing in Indian Cyber Law. Your purpose is to provide information and guidance based on the Information Technology Act, 2000, and other relevant Indian laws.
- You MUST respond in ${language}.
- Be empathetic, clear, and concise in your communication.
- Start your first response in any conversation by introducing yourself briefly.
- CRUCIALLY, you must include a disclaimer in every response that you are an AI assistant and your advice is for informational purposes only and does not constitute formal legal advice. Advise users to consult with a qualified human lawyer for serious legal matters.`;
};


export const createChat = (language: Language): Chat => {
    return ai.chats.create({
        model: 'gemini-2.5-flash',
        config: {
            systemInstruction: getSystemInstruction(language),
            temperature: 0.7,
            topP: 0.9,
            topK: 40,
        },
    });
};

export const generateComplaintReport = async (formData: Record<string, string>, language: Language): Promise<string> => {
    const prompt = `
    Generate a formal and detailed complaint letter in ${language} to be submitted to the Cyber Crime Cell in India. The tone must be formal, precise, and clear. The letter should be based on the following details provided by the victim.

    **Victim's Full Name:** ${formData.name}
    **Contact Information:** ${formData.contact}
    **Date and Time of Incident:** ${formData.incidentDate}
    **Detailed Description of the Incident:** ${formData.description}
    **Information about the Accused (if available):** ${formData.accusedInfo}
    **Available Evidence (e.g., URLs, screenshot descriptions):** ${formData.evidence}

    Structure the complaint properly, including a subject line, salutation, body detailing the incident chronologically, a concluding paragraph requesting action, and a closing. Ensure it refers to relevant types of cybercrime under the Indian IT Act, 2000 where applicable.
    `;

    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });
        return response.text;
    } catch (error) {
        console.error("Error generating complaint report:", error);
        return "An error occurred while generating the report. Please try again.";
    }
};

export const analyzeDocument = async (base64Image: string, mimeType: string, userPrompt: string, language: Language): Promise<string> => {
    const imagePart = {
        inlineData: {
            mimeType: mimeType,
            data: base64Image,
        },
    };

    const textPart = {
        text: `You are an Indian Cyber Law expert. Analyze the attached image in the context of the user's query: "${userPrompt}". Explain its potential relevance as evidence under Indian law. What kind of cybercrime could this document be related to? Provide a detailed analysis. Respond exclusively in ${language}.`,
    };

    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: { parts: [imagePart, textPart] },
        });
        return response.text;
    } catch (error) {
        console.error("Error analyzing document:", error);
        return "An error occurred while analyzing the document. Please ensure the image is clear and try again.";
    }
};
