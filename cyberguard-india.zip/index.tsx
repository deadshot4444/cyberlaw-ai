import React, { useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Language, View } from './types';
import Header from './components/Header';
import Footer from './components/Footer';
import ChatComponent from './components/Chat';
import ReportGenerator from './components/ReportGenerator';
import DocScanner from './components/DocScanner';
import Awareness from './components/Awareness';

const App = () => {
  const [currentView, setCurrentView] = useState<View>(View.ADVISOR);
  const [language, setLanguage] = useState<Language>(Language.ENGLISH);

  const renderView = () => {
    switch (currentView) {
      case View.ADVISOR:
        return <ChatComponent language={language} />;
      case View.GENERATOR:
        return <ReportGenerator language={language} />;
      case View.SCANNER:
        return <DocScanner language={language} />;
      case View.AWARENESS:
        return <Awareness language={language} />;
      default:
        return <ChatComponent language={language} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-900">
      <Header
        currentView={currentView}
        setCurrentView={setCurrentView}
        language={language}
        setLanguage={setLanguage}
      />
      <main className="flex-grow w-full">
        {renderView()}
      </main>
      <Footer />
    </div>
  );
};

const container = document.getElementById('root');
if (container) {
  const root = createRoot(container);
  root.render(<React.StrictMode><App /></React.StrictMode>);
}
