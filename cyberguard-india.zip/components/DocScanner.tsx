import React, { useState, useCallback } from 'react';
import { Language, View } from '../types';
import { UI_TEXT } from '../constants';
import { analyzeDocument } from '../services/geminiService';

interface DocScannerProps {
  language: Language;
}

const DocScanner: React.FC<DocScannerProps> = ({ language }) => {
  const [image, setImage] = useState<{ file: File; base64: string; mimeType: string; } | null>(null);
  const [prompt, setPrompt] = useState('');
  const [analysisResult, setAnalysisResult] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const T = UI_TEXT[language];

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve((reader.result as string).split(',')[1]);
      reader.onerror = (error) => reject(error);
    });
  };

  const handleFileChange = useCallback(async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && (file.type === 'image/jpeg' || file.type === 'image/png')) {
      setError('');
      setIsLoading(true);
      try {
        const base64 = await fileToBase64(file);
        setImage({ file, base64, mimeType: file.type });
      } catch (e) {
        setError('Failed to read file.');
      } finally {
        setIsLoading(false);
      }
    } else {
      setImage(null);
      setError('Please upload a valid image file (JPG, PNG).');
    }
  }, []);

  const handleSubmit = async () => {
    if (!image || !prompt || isLoading) return;
    
    setIsLoading(true);
    setError('');
    setAnalysisResult('');
    
    try {
      const result = await analyzeDocument(image.base64, image.mimeType, prompt, language);
      setAnalysisResult(result);
    } catch (err) {
      console.error(err);
      setError('An error occurred during analysis. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6 lg:p-8">
      <div className="bg-gray-800 rounded-lg shadow-xl p-6 space-y-6">
        <h2 className="text-2xl font-bold text-amber-400 border-b border-gray-700 pb-2">{T[View.SCANNER]}</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
          {/* File Upload Section */}
          <div className="space-y-4">
            <label className="block text-sm font-medium text-gray-300">Upload Document Image</label>
            <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-600 border-dashed rounded-md">
              <div className="space-y-1 text-center">
                {image ? (
                  <img src={URL.createObjectURL(image.file)} alt="Preview" className="mx-auto h-40 w-auto rounded-md" />
                ) : (
                  <svg className="mx-auto h-12 w-12 text-gray-500" stroke="currentColor" fill="none" viewBox="0 0 48 48" aria-hidden="true">
                    <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 4v.01M28 8L20 16m0 0h8m-8 0v8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                )}
                <div className="flex text-sm text-gray-400 justify-center">
                  <label htmlFor="file-upload" className="relative cursor-pointer bg-gray-700 rounded-md font-medium text-amber-400 hover:text-amber-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-offset-gray-800 focus-within:ring-amber-500 p-1">
                    <span>Upload a file</span>
                    <input id="file-upload" name="file-upload" type="file" className="sr-only" onChange={handleFileChange} accept="image/png, image/jpeg" />
                  </label>
                </div>
                <p className="text-xs text-gray-500">{T.UPLOAD_PROMPT}</p>
              </div>
            </div>
            {error && <p className="text-red-400 text-sm mt-2">{error}</p>}
          </div>

          {/* Prompt and Button Section */}
          <div className="space-y-4">
            <label htmlFor="prompt" className="block text-sm font-medium text-gray-300">{T.SCANNER_PROMPT}</label>
            <textarea
              id="prompt"
              name="prompt"
              rows={5}
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              className="w-full bg-gray-700 text-white rounded-md border-gray-600 focus:ring-amber-500 focus:border-amber-500 shadow-sm p-2"
              placeholder="e.g., Is this a phishing attempt? Check for signs of forgery."
            />
            <button
              onClick={handleSubmit}
              disabled={isLoading || !image || !prompt}
              className="w-full px-6 py-3 bg-amber-500 text-white font-semibold rounded-md hover:bg-amber-600 disabled:bg-gray-600 disabled:cursor-not-allowed transition-all duration-300 shadow-lg flex items-center justify-center"
            >
              {isLoading ? T.ANALYZING : T.ANALYZE_DOCUMENT}
            </button>
          </div>
        </div>

        {analysisResult && (
          <div className="mt-6 pt-6 border-t border-gray-700">
            <h3 className="text-xl font-bold text-amber-400 mb-4">{T.document_analysis_title}</h3>
            <div className="bg-gray-900 p-4 rounded-md text-gray-200 whitespace-pre-wrap text-sm">
              {analysisResult}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default DocScanner;
