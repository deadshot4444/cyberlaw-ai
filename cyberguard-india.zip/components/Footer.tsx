
import React from 'react';
import { APP_NAME } from '../constants';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-800 text-gray-400 text-xs text-center py-4 mt-8">
      <div className="container mx-auto px-4">
        <p>&copy; {new Date().getFullYear()} {APP_NAME}. All rights reserved.</p>
        <p className="mt-1">
          Disclaimer: This is an AI-powered tool for informational purposes only. It does not constitute legal advice. Please consult a qualified human lawyer for any legal action or decision.
        </p>
      </div>
    </footer>
  );
};

export default Footer;
