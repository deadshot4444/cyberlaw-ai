import React, { useState } from 'react';
import { Language, View } from '../types';
import { UI_TEXT } from '../constants';
import { generateComplaintReport } from '../services/geminiService';

interface ReportGeneratorProps {
  language: Language;
}

const ReportGenerator: React.FC<ReportGeneratorProps> = ({ language }) => {
  const [formData, setFormData] = useState({
    name: '',
    contact: '',
    incidentDate: '',
    description: '',
    accusedInfo: '',
    evidence: '',
  });
  const [generatedReport, setGeneratedReport] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const T = UI_TEXT[language];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setGeneratedReport('');
    try {
      const report = await generateComplaintReport(formData, language);
      setGeneratedReport(report);
    } catch (error) {
      console.error(error);
      setGeneratedReport('An error occurred while generating the report. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(generatedReport);
  };

  const handleDownload = () => {
    const blob = new Blob([generatedReport], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'cyber_complaint_report.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };
  
  const FormInput: React.FC<{
    label: string;
    id: string;
    name: string;
    value: string;
    onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
    type?: string;
    required?: boolean;
  }> = ({ label, id, name, value, onChange, type = 'text', required = false }) => (
    <div>
      <label htmlFor={id} className="block text-sm font-medium text-gray-300 mb-1">{label}</label>
      {type === 'textarea' ? (
        <textarea
          id={id}
          name={name}
          rows={4}
          value={value}
          onChange={onChange}
          required={required}
          className="w-full p-2 bg-gray-700 text-white rounded-md border-gray-600 focus:ring-amber-500 focus:border-amber-500 shadow-sm"
        />
      ) : (
        <input
          type={type}
          id={id}
          name={name}
          value={value}
          onChange={onChange}
          required={required}
          className="w-full p-2 bg-gray-700 text-white rounded-md border-gray-600 focus:ring-amber-500 focus:border-amber-500 shadow-sm"
        />
      )}
    </div>
  );

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6 lg:p-8">
      <div className="bg-gray-800 rounded-lg shadow-xl p-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          <h2 className="text-2xl font-bold text-amber-400 border-b border-gray-700 pb-2">{T[View.GENERATOR]}</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <FormInput label={T.report_name} id="name" name="name" value={formData.name} onChange={handleInputChange} required />
            <FormInput label={T.report_contact} id="contact" name="contact" value={formData.contact} onChange={handleInputChange} required />
          </div>
          <FormInput label={T.report_incident_date} id="incidentDate" name="incidentDate" type="datetime-local" value={formData.incidentDate} onChange={handleInputChange} required />
          <FormInput label={T.report_incident_desc} id="description" name="description" type="textarea" value={formData.description} onChange={handleInputChange} required />
          <FormInput label={T.report_accused_info} id="accusedInfo" name="accusedInfo" type="textarea" value={formData.accusedInfo} onChange={handleInputChange} />
          <FormInput label={T.report_evidence} id="evidence" name="evidence" type="textarea" value={formData.evidence} onChange={handleInputChange} />
          
          <div className="flex justify-end">
            <button
              type="submit"
              disabled={isLoading}
              className="px-6 py-2 bg-amber-500 text-white font-semibold rounded-md hover:bg-amber-600 disabled:bg-gray-600 disabled:cursor-not-allowed transition-all duration-300 shadow-lg flex items-center"
            >
              {isLoading && (
                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
              )}
              {isLoading ? T.GENERATING : T.GENERATE_REPORT}
            </button>
          </div>
        </form>
      </div>

      {generatedReport && (
        <div className="mt-8 bg-gray-800 rounded-lg shadow-xl p-6">
          <h3 className="text-xl font-bold text-amber-400 mb-4">{T.generated_report_title}</h3>
          <div className="bg-gray-900 p-4 rounded-md text-gray-200 whitespace-pre-wrap font-mono text-sm overflow-x-auto">
            {generatedReport}
          </div>
          <div className="flex justify-end space-x-4 mt-4">
            <button onClick={handleCopy} className="px-4 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-500 transition-colors">{T.COPY_TEXT}</button>
            <button onClick={handleDownload} className="px-4 py-2 bg-amber-500 text-white rounded-md hover:bg-amber-600 transition-colors">{T.DOWNLOAD_REPORT}</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ReportGenerator;
