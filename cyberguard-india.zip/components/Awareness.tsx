import React from 'react';
import { Language } from '../types';
import { UI_TEXT } from '../constants';

interface AwarenessProps {
  language: Language;
}

const InfoCard: React.FC<{ title: string; children: React.ReactNode; icon: JSX.Element }> = ({ title, children, icon }) => (
  <div className="bg-gray-800 rounded-lg shadow-lg p-6">
    <div className="flex items-center mb-4">
      <div className="p-2 bg-amber-500/20 rounded-full mr-4">{icon}</div>
      <h3 className="text-xl font-bold text-amber-400">{title}</h3>
    </div>
    <div className="text-gray-300 space-y-3">{children}</div>
  </div>
);

const CrimeItem: React.FC<{ title: string; description: string }> = ({ title, description }) => (
  <div>
    <h4 className="font-semibold text-gray-100">{title}</h4>
    <p className="text-sm">{description}</p>
  </div>
);

const Awareness: React.FC<AwarenessProps> = ({ language }) => {
  const T = UI_TEXT[language];

  return (
    <div className="max-w-5xl mx-auto p-4 sm:p-6 lg:p-8 space-y-8">
      <h2 className="text-3xl font-bold text-center text-white mb-4">{T.AWARENESS_TITLE}</h2>
      
      <InfoCard
        title={T.COMMON_CRIMES_TITLE}
        icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-amber-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>}
      >
        <CrimeItem title={T.phishing} description={T.phishing_desc} />
        <CrimeItem title={T.cyberstalking} description={T.cyberstalking_desc} />
        <CrimeItem title={T.identityTheft} description={T.identityTheft_desc} />
      </InfoCard>

      <InfoCard
        title={T.PREVENTION_TIPS_TITLE}
        icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-amber-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>}
      >
        <ul className="list-disc list-inside space-y-2 text-sm">
          <li>{T.prevention1}</li>
          <li>{T.prevention2}</li>
          <li>{T.prevention3}</li>
        </ul>
      </InfoCard>

      <InfoCard
        title={T.LEGAL_INFO_TITLE}
        icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-amber-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v11.494m-5.45-6.895l10.9 4.266M3.636 9.879l16.728 6.532M5.45 16.121L18.55 9.88M12 21.75c-4.97 0-9-2.015-9-4.5s4.03-4.5 9-4.5 9 2.015 9 4.5-4.03 4.5-9 4.5z" /></svg>}
      >
        <ul className="list-disc list-inside space-y-2 text-sm">
          <li>{T.legal1}</li>
          <li>{T.legal2}</li>
          <li>{T.legal3}</li>
        </ul>
      </InfoCard>

    </div>
  );
};

export default Awareness;
