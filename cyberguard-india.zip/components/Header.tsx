
import React, { useState } from 'react';
import { Language, View } from '../types';
import { APP_NAME, UI_TEXT } from '../constants';

interface HeaderProps {
  currentView: View;
  setCurrentView: (view: View) => void;
  language: Language;
  setLanguage: (language: Language) => void;
}

const NavButton: React.FC<{
  label: string;
  isActive: boolean;
  onClick: () => void;
}> = ({ label, isActive, onClick }) => {
  return (
    <button
      onClick={onClick}
      className={`px-4 py-2 text-sm font-medium rounded-md transition-all duration-300 ${
        isActive
          ? 'bg-amber-500 text-white shadow-lg'
          : 'text-gray-300 hover:bg-gray-700 hover:text-white'
      }`}
    >
      {label}
    </button>
  );
};

const Header: React.FC<HeaderProps> = ({ currentView, setCurrentView, language, setLanguage }) => {
  const [isDropdownOpen, setDropdownOpen] = useState(false);
  const T = UI_TEXT[language];

  return (
    <header className="bg-gray-800/80 backdrop-blur-sm shadow-lg sticky top-0 z-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-4">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-amber-400" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M10 1.944A11.954 11.954 0 012.166 5C2.056 5.649 2 6.319 2 7c0 5.225 3.34 9.67 8 11.317C14.66 16.67 18 12.225 18 7c0-.682-.057-1.35-.166-2.001A11.954 11.954 0 0110 1.944zM10 18c-5.145 0-8-3.582-8-8s2.855-8 8-8 8 3.582 8 8-2.855 8-8 8z" clipRule="evenodd" />
              <path d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" />
            </svg>
            <h1 className="text-xl font-bold text-white">{APP_NAME}</h1>
          </div>

          <nav className="hidden md:flex items-center space-x-2 bg-gray-900 p-1 rounded-lg">
            {(Object.keys(View) as Array<keyof typeof View>).map((key) => (
              <NavButton
                key={key}
                label={T[View[key]]}
                isActive={currentView === View[key]}
                onClick={() => setCurrentView(View[key])}
              />
            ))}
          </nav>

          <div className="relative">
            <button
              onClick={() => setDropdownOpen(!isDropdownOpen)}
              className="flex items-center space-x-2 px-3 py-2 border border-gray-600 rounded-md text-sm hover:bg-gray-700 transition-colors"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path d="M10 2a8 8 0 100 16 8 8 0 000-16zM5.022 7.214a.75.75 0 011.06 0L10 11.152l3.918-3.938a.75.75 0 111.06 1.06l-4.25 4.25a.75.75 0 01-1.06 0L5.022 8.274a.75.75 0 010-1.06z" clipRule="evenodd" />
              </svg>
              <span>{language}</span>
            </button>
            {isDropdownOpen && (
              <div
                className="absolute right-0 mt-2 w-40 bg-gray-800 border border-gray-700 rounded-md shadow-xl z-20"
                onMouseLeave={() => setDropdownOpen(false)}
              >
                {(Object.values(Language)).map(lang => (
                  <a
                    key={lang}
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                      setLanguage(lang);
                      setDropdownOpen(false);
                    }}
                    className="block px-4 py-2 text-sm text-gray-300 hover:bg-amber-500 hover:text-white"
                  >
                    {lang}
                  </a>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
      <nav className="md:hidden bg-gray-900 p-2 flex justify-around">
        {(Object.keys(View) as Array<keyof typeof View>).map((key) => (
          <NavButton
            key={key}
            label={T[View[key]]}
            isActive={currentView === View[key]}
            onClick={() => setCurrentView(View[key])}
          />
        ))}
      </nav>
    </header>
  );
};

export default Header;
