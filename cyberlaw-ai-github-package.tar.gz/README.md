# CyberLaw AI - Multilingual Legal Advisor

An AI-powered legal advisor platform specializing in cyber law and digital rights protection in India. The application provides comprehensive tools including an AI legal chatbot, complaint generation system, document analysis with OCR capabilities, and legal awareness resources.

## 🌟 Features

- **AI Legal Advisor**: Chat with Gemini AI for cyber law guidance
- **Multilingual Support**: English, Hindi, and Marathi languages
- **Complaint Generator**: Generate formal legal complaints with PDF download
- **Document Scanner**: OCR text extraction from legal documents
- **Legal Awareness**: Educational resources and legal references

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ 
- Google Gemini API key

### Installation
```bash
npm install
```

### Environment Variables
Create a `.env` file:
```env
GEMINI_API_KEY=your_gemini_api_key_here
```

### Development
```bash
npm run dev
```

Visit `http://localhost:5000` to view the application.

## 🏗️ Architecture

- **Frontend**: React with TypeScript, Tailwind CSS, shadcn/ui
- **Backend**: Express.js with TypeScript
- **AI**: Google Gemini 2.5 Flash/Pro models
- **OCR**: Tesseract.js for document text extraction
- **Storage**: In-memory storage (production ready for external DB)

## 📦 Deployment

### Vercel (Recommended)
1. Push code to GitHub
2. Connect repository to [Vercel](https://vercel.com)
3. Add `GEMINI_API_KEY` environment variable
4. Deploy automatically

See [DEPLOYMENT.md](DEPLOYMENT.md) for detailed instructions.

## 🛠️ Tech Stack

- **Frontend**: React, TypeScript, Tailwind CSS, Wouter, TanStack Query
- **Backend**: Express.js, TypeScript, Multer
- **AI**: Google Gemini AI
- **OCR**: Tesseract.js
- **Build**: Vite, ESBuild
- **UI**: shadcn/ui, Radix UI, Lucide React

## 📝 Legal Disclaimer

This application provides general legal information and should not be considered as professional legal advice. Always consult with qualified legal professionals for specific legal matters.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## 📄 License

This project is licensed under the MIT License.

## 🔗 Links

- [Live Demo](https://your-app.vercel.app) (after deployment)
- [Documentation](README-VERCEL-DEPLOYMENT.md)
- [Google Gemini AI](https://ai.google.com/)

---

Built with ❤️ for accessible legal technology in India