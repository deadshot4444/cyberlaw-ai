import { useState } from "react";
import { Bot, FileText, Scan, Info } from "lucide-react";
import Header from "@/components/header";
import Footer from "@/components/footer";
import ChatInterface from "@/components/chat-interface";
import ComplaintGenerator from "@/components/complaint-generator";
import DocumentScanner from "@/components/document-scanner";
import LegalAwareness from "@/components/legal-awareness";

type TabId = "ai-advisor" | "complaint-generator" | "document-scanner" | "awareness";

export default function Home() {
  const [activeTab, setActiveTab] = useState<TabId>("ai-advisor");
  const [language, setLanguage] = useState("en");

  const tabs = [
    {
      id: "ai-advisor" as TabId,
      icon: Bot,
      label: language === 'hi' ? "AI कानूनी सलाहकार"
             : language === 'mr' ? "AI कायदेशीर सल्लागार"
             : "AI Legal Advisor"
    },
    {
      id: "complaint-generator" as TabId,
      icon: FileText,
      label: language === 'hi' ? "शिकायत जनरेटर"
             : language === 'mr' ? "तक्रार जनरेटर"
             : "Complaint Generator"
    },
    {
      id: "document-scanner" as TabId,
      icon: Scan,
      label: language === 'hi' ? "दस्तावेज़ स्कैनर"
             : language === 'mr' ? "कागदपत्र स्कॅनर"
             : "Document Scanner"
    },
    {
      id: "awareness" as TabId,
      icon: Info,
      label: language === 'hi' ? "कानूनी जागरूकता"
             : language === 'mr' ? "कायदेशीर जागरूकता"
             : "Legal Awareness"
    }
  ];

  const renderTabContent = () => {
    switch (activeTab) {
      case "ai-advisor":
        return <ChatInterface language={language} />;
      case "complaint-generator":
        return <ComplaintGenerator language={language} />;
      case "document-scanner":
        return <DocumentScanner language={language} />;
      case "awareness":
        return <LegalAwareness language={language} />;
      default:
        return <ChatInterface language={language} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header language={language} onLanguageChange={setLanguage} />
      
      {/* Navigation Tabs */}
      <nav className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-8 overflow-x-auto scrollbar-hide">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                className={`nav-tab flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm whitespace-nowrap transition-colors ${
                  activeTab === tab.id
                    ? 'border-primary text-primary'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
                onClick={() => setActiveTab(tab.id)}
                data-testid={`tab-${tab.id}`}
              >
                <tab.icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8" data-testid="main-content">
        {renderTabContent()}
      </main>

      <Footer />
    </div>
  );
}
