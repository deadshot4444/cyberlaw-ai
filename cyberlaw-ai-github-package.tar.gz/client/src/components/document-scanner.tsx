import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { FileUp, Copy, Download, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface DocumentScannerProps {
  language: string;
}

interface ProcessingOptions {
  extractText: boolean;
  analyzeKeywords: boolean;
  generateSummary: boolean;
  translate: boolean;
}

interface OCRResult {
  text: string;
  confidence: number;
}

interface DocumentAnalysis {
  documentType?: string;
  legalTermsCount?: number;
  relevantSections?: string[];
  summary?: string;
}

interface ProcessingResult {
  document: any;
  ocrResult: OCRResult;
  analysis: DocumentAnalysis;
}

export default function DocumentScanner({ language }: DocumentScannerProps) {
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [processingOptions, setProcessingOptions] = useState<ProcessingOptions>({
    extractText: true,
    analyzeKeywords: false,
    generateSummary: false,
    translate: false,
  });
  const [results, setResults] = useState<ProcessingResult[]>([]);
  const { toast } = useToast();

  const uploadMutation = useMutation({
    mutationFn: async (files: File[]) => {
      const formData = new FormData();
      files.forEach(file => {
        formData.append('documents', file);
      });

      const response = await fetch('/api/documents/upload', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error('Upload failed');
      }

      return response.json();
    },
    onSuccess: (data) => {
      setResults(data.results || []);
      toast({
        title: language === 'hi' ? "दस्तावेज़ सफलतापूर्वक प्रोसेस किए गए"
               : language === 'mr' ? "कागदपत्रे यशस्वीरित्या प्रक्रिया केली"
               : "Documents processed successfully",
        description: language === 'hi' ? "टेक्स्ट निकाला गया और विश्लेषण पूरा हुआ।"
                    : language === 'mr' ? "मजकूर काढला गेला आणि विश्लेषण पूर्ण झाले."
                    : "Text extracted and analysis completed.",
      });
    },
    onError: (error) => {
      toast({
        title: language === 'hi' ? "त्रुटि"
               : language === 'mr' ? "त्रुटी"
               : "Error",
        description: error instanceof Error ? error.message : "Document processing failed",
        variant: "destructive",
      });
    },
  });

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setSelectedFiles(Array.from(e.target.files));
    }
  };

  const handleUpload = () => {
    if (selectedFiles.length === 0) {
      toast({
        title: language === 'hi' ? "कोई फ़ाइल नहीं चुनी गई"
               : language === 'mr' ? "कोणतीही फाइल निवडली नाही"
               : "No files selected",
        description: language === 'hi' ? "कृपया अपलोड करने के लिए कम से कम एक फ़ाइल चुनें।"
                    : language === 'mr' ? "कृपया अपलोड करण्यासाठी किमान एक फाइल निवडा."
                    : "Please select at least one file to upload.",
        variant: "destructive",
      });
      return;
    }

    uploadMutation.mutate(selectedFiles);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: language === 'hi' ? "कॉपी किया गया"
             : language === 'mr' ? "कॉपी केले"
             : "Copied",
      description: language === 'hi' ? "टेक्स्ट क्लिपबोर्ड पर कॉपी किया गया।"
                  : language === 'mr' ? "मजकूर क्लिपबोर्डवर कॉपी केला."
                  : "Text copied to clipboard.",
    });
  };

  const exportResults = () => {
    const exportData = results.map(result => ({
      filename: result.document?.filename,
      extractedText: result.ocrResult?.text,
      analysis: result.analysis,
    }));

    const blob = new Blob([JSON.stringify(exportData, null, 2)], { 
      type: 'application/json' 
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'document-analysis.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const processingOptionLabels = {
    extractText: language === 'hi' ? "टेक्स्ट कंटेंट निकालें"
                 : language === 'mr' ? "मजकूर सामग्री काढा"
                 : "Extract text content",
    analyzeKeywords: language === 'hi' ? "कानूनी कीवर्ड के लिए विश्लेषण करें"
                     : language === 'mr' ? "कायदेशीर मुख्यशब्दांसाठी विश्लेषण करा"
                     : "Analyze for legal keywords",
    generateSummary: language === 'hi' ? "सारांश जेनरेट करें"
                     : language === 'mr' ? "सारांश तयार करा"
                     : "Generate summary",
    translate: language === 'hi' ? "चयनित भाषा में अनुवाद करें"
               : language === 'mr' ? "निवडलेल्या भाषेत भाषांतर करा"
               : "Translate to selected language"
  };

  return (
    <div className="max-w-4xl mx-auto">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-gray-900 mb-2">
            {language === 'hi' ? "दस्तावेज़ स्कैनर और टेक्स्ट एक्सट्रैक्टर"
             : language === 'mr' ? "कागदपत्र स्कॅनर आणि मजकूर काढणारा"
             : "Document Scanner & Text Extractor"}
          </CardTitle>
          <p className="text-gray-600">
            {language === 'hi' ? "कानूनी दस्तावेज़ अपलोड करें और विश्लेषण और प्रसंस्करण के लिए टेक्स्ट निकालें।"
             : language === 'mr' ? "कायदेशीर कागदपत्रे अपलोड करा आणि विश्लेषण आणि प्रक्रियेसाठी मजकूर काढा."
             : "Upload legal documents and extract text for analysis and processing."}
          </p>
        </CardHeader>
        
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Upload Section */}
            <div>
              <div 
                className="upload-zone mb-6"
                onClick={() => document.getElementById('file-input')?.click()}
                data-testid="upload-zone"
              >
                <FileUp className="mx-auto text-4xl text-gray-400 mb-4" />
                <p className="text-lg font-medium text-gray-700 mb-2">
                  {language === 'hi' ? "दस्तावेज़ अपलोड करें"
                   : language === 'mr' ? "कागदपत्र अपलोड करा"
                   : "Upload Document"}
                </p>
                <p className="text-sm text-gray-500 mb-4">
                  {language === 'hi' ? "PDF, JPG, PNG फ़ाइलों के लिए सपोर्ट"
                   : language === 'mr' ? "PDF, JPG, PNG फायलींसाठी समर्थन"
                   : "Support for PDF, JPG, PNG files"}
                </p>
                <Button className="bg-primary text-white hover:bg-primary-dark" data-testid="choose-files-button">
                  <FileUp className="w-4 h-4 mr-2" />
                  {language === 'hi' ? "फ़ाइलें चुनें"
                   : language === 'mr' ? "फायली निवडा"
                   : "Choose Files"}
                </Button>
                <input
                  id="file-input"
                  type="file"
                  className="hidden"
                  multiple
                  accept=".pdf,.png,.jpg,.jpeg"
                  onChange={handleFileSelect}
                  data-testid="file-input"
                />
              </div>

              {selectedFiles.length > 0 && (
                <div className="mb-6">
                  <h4 className="font-medium text-gray-900 mb-2">
                    {language === 'hi' ? "चयनित फ़ाइलें:"
                     : language === 'mr' ? "निवडलेल्या फायली:"
                     : "Selected Files:"}
                  </h4>
                  <ul className="space-y-1">
                    {selectedFiles.map((file, index) => (
                      <li key={index} className="text-sm text-gray-600" data-testid={`selected-file-${index}`}>
                        {file.name} ({(file.size / 1024 / 1024).toFixed(2)} MB)
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              
              {/* Processing Options */}
              <div className="space-y-4">
                <h3 className="font-semibold text-gray-900">
                  {language === 'hi' ? "प्रसंस्करण विकल्प"
                   : language === 'mr' ? "प्रक्रिया पर्याय"
                   : "Processing Options"}
                </h3>
                <div className="space-y-3">
                  {Object.entries(processingOptions).map(([key, value]) => (
                    <div key={key} className="flex items-center space-x-3">
                      <Checkbox
                        id={key}
                        checked={value}
                        onCheckedChange={(checked) =>
                          setProcessingOptions(prev => ({
                            ...prev,
                            [key]: checked as boolean,
                          }))
                        }
                        data-testid={`option-${key}`}
                      />
                      <label htmlFor={key} className="text-sm cursor-pointer">
                        {processingOptionLabels[key as keyof ProcessingOptions]}
                      </label>
                    </div>
                  ))}
                </div>
              </div>

              <Button
                onClick={handleUpload}
                disabled={selectedFiles.length === 0 || uploadMutation.isPending}
                className="w-full mt-6 bg-primary text-white hover:bg-primary-dark"
                data-testid="process-button"
              >
                {uploadMutation.isPending ? (
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                ) : (
                  <FileText className="w-4 h-4 mr-2" />
                )}
                {language === 'hi' ? "प्रोसेस करें"
                 : language === 'mr' ? "प्रक्रिया करा"
                 : "Process Documents"}
              </Button>
            </div>
            
            {/* Results Section */}
            <div>
              <div className="bg-gray-50 rounded-xl p-6 h-96 overflow-y-auto" data-testid="results-area">
                {results.length === 0 ? (
                  <div className="text-center text-gray-400 mt-20">
                    <FileText className="mx-auto text-6xl mb-4" />
                    <p>
                      {language === 'hi' ? "निकाला गया टेक्स्ट यहाँ दिखेगा"
                       : language === 'mr' ? "काढलेला मजकूर येथे दिसेल"
                       : "Extracted text will appear here"}
                    </p>
                    <p className="text-sm mt-2">
                      {language === 'hi' ? "शुरू करने के लिए एक दस्तावेज़ अपलोड करें"
                       : language === 'mr' ? "सुरू करण्यासाठी एक कागदपत्र अपलोड करा"
                       : "Upload a document to get started"}
                    </p>
                  </div>
                ) : (
                  <div className="space-y-6">
                    {results.map((result, index) => (
                      <div key={index} className="space-y-4">
                        <div className="flex items-center justify-between">
                          <h4 className="font-medium text-gray-900" data-testid={`result-filename-${index}`}>
                            {result.document?.filename || `Document ${index + 1}`}
                          </h4>
                          {result.ocrResult?.confidence && (
                            <Badge variant="outline" data-testid={`confidence-${index}`}>
                              {(result.ocrResult.confidence * 100).toFixed(0)}% confidence
                            </Badge>
                          )}
                        </div>

                        {result.ocrResult?.text && (
                          <div>
                            <h5 className="font-medium text-gray-700 mb-2">
                              {language === 'hi' ? "निकाला गया टेक्स्ट:"
                               : language === 'mr' ? "काढलेला मजकूर:"
                               : "Extracted Text:"}
                            </h5>
                            <div className="prose prose-sm max-w-none text-gray-700 bg-white p-3 rounded border max-h-32 overflow-y-auto">
                              <p className="whitespace-pre-wrap" data-testid={`extracted-text-${index}`}>
                                {result.ocrResult.text}
                              </p>
                            </div>
                          </div>
                        )}

                        {result.analysis && Object.keys(result.analysis).length > 0 && (
                          <div className="p-4 bg-blue-50 rounded-lg">
                            <h5 className="font-medium text-blue-900 mb-2">
                              {language === 'hi' ? "AI विश्लेषण:"
                               : language === 'mr' ? "AI विश्लेषण:"
                               : "AI Analysis:"}
                            </h5>
                            <ul className="text-sm text-blue-800 space-y-1" data-testid={`analysis-${index}`}>
                              {result.analysis.documentType && (
                                <li>
                                  {language === 'hi' ? "दस्तावेज़ प्रकार: "
                                   : language === 'mr' ? "कागदपत्राचा प्रकार: "
                                   : "Document type: "}
                                  {result.analysis.documentType}
                                </li>
                              )}
                              {result.analysis.legalTermsCount && (
                                <li>
                                  {language === 'hi' ? "कानूनी शब्द पहचाने गए: "
                                   : language === 'mr' ? "कायदेशीर शब्द ओळखले: "
                                   : "Key legal terms identified: "}
                                  {result.analysis.legalTermsCount}
                                </li>
                              )}
                              {result.analysis.relevantSections && result.analysis.relevantSections.length > 0 && (
                                <li>
                                  {language === 'hi' ? "संबंधित धाराएं: "
                                   : language === 'mr' ? "संबंधित कलमे: "
                                   : "Relevant sections: "}
                                  {result.analysis.relevantSections.join(", ")}
                                </li>
                              )}
                            </ul>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
              
              {results.length > 0 && (
                <div className="flex space-x-3 mt-4">
                  <Button 
                    variant="outline" 
                    className="flex-1"
                    onClick={() => {
                      const allText = results.map(r => r.ocrResult?.text || '').join('\n\n');
                      copyToClipboard(allText);
                    }}
                    data-testid="copy-text-button"
                  >
                    <Copy className="w-4 h-4 mr-1" />
                    {language === 'hi' ? "टेक्स्ट कॉपी करें"
                     : language === 'mr' ? "मजकूर कॉपी करा"
                     : "Copy Text"}
                  </Button>
                  <Button 
                    variant="outline" 
                    className="flex-1"
                    onClick={exportResults}
                    data-testid="export-button"
                  >
                    <Download className="w-4 h-4 mr-1" />
                    {language === 'hi' ? "एक्सपोर्ट"
                     : language === 'mr' ? "निर्यात"
                     : "Export"}
                  </Button>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
