import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { FileUp, Download, Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface ComplaintGeneratorProps {
  language: string;
}

const complaintSchema = z.object({
  complaintType: z.string().min(1, "Complaint type is required"),
  incidentDate: z.string().min(1, "Incident date is required"),
  complainantName: z.string().min(1, "Name is required"),
  contactNumber: z.string().min(10, "Valid contact number is required"),
  email: z.string().email("Valid email is required"),
  description: z.string().min(50, "Description must be at least 50 characters"),
});

type ComplaintFormData = z.infer<typeof complaintSchema>;

export default function ComplaintGenerator({ language }: ComplaintGeneratorProps) {
  const [files, setFiles] = useState<File[]>([]);
  const { toast } = useToast();

  const form = useForm<ComplaintFormData>({
    resolver: zodResolver(complaintSchema),
    defaultValues: {
      complaintType: "",
      incidentDate: "",
      complainantName: "",
      contactNumber: "",
      email: "",
      description: "",
    },
  });

  const createComplaintMutation = useMutation({
    mutationFn: async (data: ComplaintFormData) => {
      const response = await apiRequest("POST", "/api/complaints", {
        ...data,
        incidentDate: new Date(data.incidentDate).toISOString(),
        evidence: files.map(f => ({ name: f.name, size: f.size, type: f.type })),
      });
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: language === 'hi' ? "शिकायत सफलतापूर्वक बनाई गई"
               : language === 'mr' ? "तक्रार यशस्वीरित्या तयार केली"
               : "Complaint generated successfully",
        description: language === 'hi' ? "आपकी शिकायत तैयार की गई है और डाउनलोड के लिए उपलब्ध है।"
                    : language === 'mr' ? "तुमची तक्रार तयार केली गेली आहे आणि डाउनलोडसाठी उपलब्ध आहे."
                    : "Your complaint has been generated and is ready for download.",
      });
      
      // Download PDF
      if (data.pdfContent) {
        const blob = new Blob([data.pdfContent], { type: 'text/html' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `complaint-${data.id}.html`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      }
    },
    onError: (error) => {
      toast({
        title: language === 'hi' ? "त्रुटि"
               : language === 'mr' ? "त्रुटी"
               : "Error",
        description: error instanceof Error ? error.message : "Failed to generate complaint",
        variant: "destructive",
      });
    },
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFiles(Array.from(e.target.files));
    }
  };

  const onSubmit = (data: ComplaintFormData) => {
    createComplaintMutation.mutate(data);
  };

  const complaintTypes = [
    { value: "cyberbullying", 
      label: language === 'hi' ? "साइबर बुलिंग/उत्पीड़न"
             : language === 'mr' ? "सायबर गुंडगिरी/छळ"
             : "Cyberbullying/Harassment" 
    },
    { value: "fraud", 
      label: language === 'hi' ? "ऑनलाइन वित्तीय धोखाधड़ी"
             : language === 'mr' ? "ऑनलाइन आर्थिक फसवणूक"
             : "Online Financial Fraud" 
    },
    { value: "identity-theft", 
      label: language === 'hi' ? "पहचान चोरी"
             : language === 'mr' ? "ओळख चोरी"
             : "Identity Theft" 
    },
    { value: "privacy-breach", 
      label: language === 'hi' ? "गोपनीयता उल्लंघन"
             : language === 'mr' ? "गोपनीयता उल्लंघन"
             : "Privacy Breach" 
    },
    { value: "hacking", 
      label: language === 'hi' ? "हैकिंग/अनधिकृत पहुंच"
             : language === 'mr' ? "हॅकिंग/अनधिकृत प्रवेश"
             : "Hacking/Unauthorized Access" 
    },
    { value: "other", 
      label: language === 'hi' ? "अन्य"
             : language === 'mr' ? "इतर"
             : "Other" 
    },
  ];

  return (
    <div className="max-w-4xl mx-auto">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-gray-900 mb-2">
            {language === 'hi' ? "शिकायत रिपोर्ट जनरेटर"
             : language === 'mr' ? "तक्रार अहवाल जनरेटर"
             : "Complaint Report Generator"}
          </CardTitle>
          <p className="text-gray-600">
            {language === 'hi' ? "साइबर अपराध और डिजिटल उल्लंघन के लिए एक संरचित कानूनी शिकायत तैयार करें।"
             : language === 'mr' ? "सायबर गुन्हे आणि डिजिटल उल्लंघनासाठी संरचित कायदेशीर तक्रार तयार करा."
             : "Generate a structured legal complaint for cyber crimes and digital violations."}
          </p>
        </CardHeader>
        
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="complaintType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>
                        {language === 'hi' ? "शिकायत का प्रकार"
                         : language === 'mr' ? "तक्रारीचा प्रकार"
                         : "Type of Complaint"}
                      </FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="complaint-type-select">
                            <SelectValue placeholder={
                              language === 'hi' ? "शिकायत का प्रकार चुनें"
                              : language === 'mr' ? "तक्रारीचा प्रकार निवडा"
                              : "Select complaint type"
                            } />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {complaintTypes.map((type) => (
                            <SelectItem key={type.value} value={type.value}>
                              {type.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="incidentDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>
                        {language === 'hi' ? "घटना की तारीख"
                         : language === 'mr' ? "घटनेची तारीख"
                         : "Incident Date"}
                      </FormLabel>
                      <FormControl>
                        <Input type="date" {...field} data-testid="incident-date" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="complainantName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>
                        {language === 'hi' ? "आपका नाम"
                         : language === 'mr' ? "तुमचे नाव"
                         : "Your Name"}
                      </FormLabel>
                      <FormControl>
                        <Input 
                          placeholder={
                            language === 'hi' ? "अपना पूरा नाम दर्ज करें"
                            : language === 'mr' ? "तुमचे पूर्ण नाव टाका"
                            : "Enter your full name"
                          } 
                          {...field} 
                          data-testid="complainant-name"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="contactNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>
                        {language === 'hi' ? "संपर्क नंबर"
                         : language === 'mr' ? "संपर्क क्रमांक"
                         : "Contact Number"}
                      </FormLabel>
                      <FormControl>
                        <Input 
                          type="tel" 
                          placeholder="+91 XXXXXXXXXX" 
                          {...field} 
                          data-testid="contact-number"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      {language === 'hi' ? "ईमेल पता"
                       : language === 'mr' ? "ईमेल पत्ता"
                       : "Email Address"}
                    </FormLabel>
                    <FormControl>
                      <Input 
                        type="email" 
                        placeholder="your.email@example.com" 
                        {...field} 
                        data-testid="email"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      {language === 'hi' ? "विस्तृत विवरण"
                       : language === 'mr' ? "तपशीलवार वर्णन"
                       : "Detailed Description"}
                    </FormLabel>
                    <FormControl>
                      <Textarea 
                        rows={6} 
                        placeholder={
                          language === 'hi' ? "घटना के बारे में विस्तृत जानकारी प्रदान करें, जिसमें तारीख, समय, सबूत और अन्य प्रासंगिक विवरण शामिल हैं..."
                          : language === 'mr' ? "घटनेबद्दल तपशीलवार माहिती द्या, ज्यामध्ये तारीख, वेळ, पुरावे आणि इतर संबंधित तपशील समाविष्ट आहेत..."
                          : "Provide detailed information about the incident, including dates, times, evidence, and any other relevant details..."
                        } 
                        {...field} 
                        data-testid="description"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {language === 'hi' ? "सबूत/सहायक दस्तावेज"
                   : language === 'mr' ? "पुरावे/सहाय्यक कागदपत्रे"
                   : "Evidence/Supporting Documents"}
                </label>
                <div className="upload-zone" data-testid="file-upload-zone">
                  <FileUp className="mx-auto text-3xl text-gray-400 mb-2" />
                  <p className="text-sm text-gray-600">
                    {language === 'hi' ? "स्क्रीनशॉट, ईमेल या अन्य सबूत अपलोड करने के लिए क्लिक करें"
                     : language === 'mr' ? "स्क्रीनशॉट, ईमेल किंवा इतर पुरावे अपलोड करण्यासाठी क्लिक करा"
                     : "Click to upload screenshots, emails, or other evidence"}
                  </p>
                  <p className="text-xs text-gray-500 mt-1">PNG, JPG, PDF up to 10MB</p>
                  <input 
                    type="file" 
                    className="hidden" 
                    multiple 
                    accept=".png,.jpg,.jpeg,.pdf"
                    onChange={handleFileChange}
                    data-testid="file-input"
                  />
                </div>
                {files.length > 0 && (
                  <div className="mt-2">
                    <p className="text-sm text-gray-600 mb-1">
                      {language === 'hi' ? "चयनित फाइलें:"
                       : language === 'mr' ? "निवडलेल्या फायली:"
                       : "Selected files:"}
                    </p>
                    <ul className="text-sm text-gray-500 space-y-1">
                      {files.map((file, index) => (
                        <li key={index} data-testid={`selected-file-${index}`}>
                          {file.name} ({(file.size / 1024 / 1024).toFixed(2)} MB)
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
              
              <div className="flex space-x-4">
                <Button 
                  type="button" 
                  variant="outline" 
                  className="flex-1"
                  data-testid="save-draft-button"
                >
                  <Save className="w-4 h-4 mr-2" />
                  {language === 'hi' ? "ड्राफ्ट के रूप में सेव करें"
                   : language === 'mr' ? "मसुदा म्हणून जतन करा"
                   : "Save as Draft"}
                </Button>
                <Button 
                  type="submit" 
                  className="flex-1 bg-primary text-white hover:bg-primary-dark"
                  disabled={createComplaintMutation.isPending}
                  data-testid="generate-complaint-button"
                >
                  {createComplaintMutation.isPending ? (
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  ) : (
                    <Download className="w-4 h-4 mr-2" />
                  )}
                  {language === 'hi' ? "शिकायत जेनरेट करें"
                   : language === 'mr' ? "तक्रार जनरेट करा"
                   : "Generate Complaint"}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
