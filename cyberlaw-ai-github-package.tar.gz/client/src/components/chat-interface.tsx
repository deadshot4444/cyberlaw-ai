import { useState, useRef, useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Send, Bot, User, Shield, CreditCard, ShieldQuestion } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";

interface ChatInterfaceProps {
  language: string;
}

interface ChatMessage {
  id: string;
  message: string;
  response: string | null;
  isUser: boolean;
  timestamp: Date;
}

interface AIResponse {
  response: string;
  relevantSections?: string[];
  suggestedActions?: string[];
}

export default function ChatInterface({ language }: ChatInterfaceProps) {
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [message, setMessage] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const queryClient = useQueryClient();

  // Create chat session
  const createSessionMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/chat/session", {
        language,
      });
      return response.json();
    },
    onSuccess: (data) => {
      setCurrentSessionId(data.id);
    },
  });

  // Send message
  const sendMessageMutation = useMutation({
    mutationFn: async ({ sessionId, message }: { sessionId: string; message: string }) => {
      const response = await apiRequest("POST", "/api/chat/message", {
        sessionId,
        message,
        language,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/chat/session", currentSessionId, "messages"] });
      setMessage("");
    },
  });

  // Get messages
  const { data: messages = [], isLoading } = useQuery<ChatMessage[]>({
    queryKey: ["/api/chat/session", currentSessionId, "messages"],
    enabled: !!currentSessionId,
  });

  // Initialize session on mount
  useEffect(() => {
    if (!currentSessionId) {
      createSessionMutation.mutate();
    }
  }, [language]);

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = () => {
    if (!message.trim() || !currentSessionId || sendMessageMutation.isPending) return;
    
    sendMessageMutation.mutate({
      sessionId: currentSessionId,
      message: message.trim(),
    });
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const quickActions = [
    {
      icon: Shield,
      title: language === 'hi' ? "साइबर अपराध की रिपोर्ट करें" 
            : language === 'mr' ? "सायबर गुन्ह्याची तक्रार करा"
            : "Report Cyber Crime",
      subtitle: language === 'hi' ? "ऑनलाइन शिकायत दर्ज करें"
                : language === 'mr' ? "ऑनलाइन तक्रार नोंदवा"
                : "File online complaint"
    },
    {
      icon: ShieldQuestion,
      title: language === 'hi' ? "गोपनीयता अधिकार"
            : language === 'mr' ? "गोपनीयता हक्क"
            : "Privacy Rights",
      subtitle: language === 'hi' ? "अपने डिजिटल अधिकारों को जानें"
                : language === 'mr' ? "तुमचे डिजिटल हक्क जाणून घ्या"
                : "Know your digital rights"
    },
    {
      icon: CreditCard,
      title: language === 'hi' ? "ऑनलाइन धोखाधड़ी"
            : language === 'mr' ? "ऑनलाइन फसवणूक"
            : "Online Fraud",
      subtitle: language === 'hi' ? "वित्तीय धोखाधड़ी की रिपोर्ट करें"
                : language === 'mr' ? "आर्थिक फसवणुकीची तक्रार करा"
                : "Report financial fraud"
    }
  ];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      {/* Chat Interface */}
      <div className="lg:col-span-2">
        <Card className="h-[600px] flex flex-col" data-testid="chat-container">
          <CardHeader className="border-b border-gray-200">
            <CardTitle className="text-xl font-semibold text-gray-900 mb-2">
              {language === 'hi' ? "AI कानूनी सलाहकार"
               : language === 'mr' ? "AI कायदेशीर सल्लागार"
               : "AI Legal Advisor"}
            </CardTitle>
            <p className="text-sm text-gray-600">
              {language === 'hi' ? "साइबर कानून, डेटा सुरक्षा, डिजिटल अधिकार और अधिक के बारे में प्रश्न पूछें।"
               : language === 'mr' ? "सायबर कायदा, डेटा संरक्षण, डिजिटल हक्क आणि बरेच काही विषयी प्रश्न विचारा।"
               : "Ask questions about cyber law, data protection, digital rights, and more."}
            </p>
          </CardHeader>
          
          <CardContent className="flex-1 p-6 overflow-y-auto space-y-4" data-testid="chat-messages">
            {/* Welcome Message */}
            <div className="flex items-start space-x-3">
              <div className="bg-primary text-white p-2 rounded-full flex-shrink-0">
                <Bot className="w-4 h-4" />
              </div>
              <div className="chat-message-bot">
                <p className="text-sm text-gray-800">
                  {language === 'hi' ? "नमस्ते! मैं साइबर कानून में विशेषज्ञ आपका AI कानूनी सलाहकार हूं। आज मैं आपकी कैसे मदद कर सकता हूं?"
                   : language === 'mr' ? "नमस्कार! मी सायबर कायद्यात तज्ञ असलेला तुमचा AI कायदेशीर सल्लागार आहे. आज मी तुमची कशी मदत करू शकतो?"
                   : "Hello! I'm your AI legal advisor specializing in cyber law. How can I help you today?"}
                </p>
                <span className="text-xs text-gray-500 mt-1 block">
                  {new Date().toLocaleTimeString()}
                </span>
              </div>
            </div>

            {/* Messages */}
            {isLoading ? (
              <div className="flex justify-center" data-testid="loading-messages">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : (
              messages.map((msg: ChatMessage) => (
                <div key={msg.id}>
                  {/* User Message */}
                  <div className="flex items-start space-x-3 justify-end mb-4">
                    <div className="chat-message-user">
                      <p className="text-sm" data-testid={`user-message-${msg.id}`}>{msg.message}</p>
                      <span className="text-xs text-primary-dark mt-1 block opacity-75">
                        {new Date(msg.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                    <div className="bg-gray-200 p-2 rounded-full flex-shrink-0">
                      <User className="w-4 h-4 text-gray-600" />
                    </div>
                  </div>

                  {/* Bot Response */}
                  {msg.response && (
                    <div className="flex items-start space-x-3 mb-4">
                      <div className="bg-primary text-white p-2 rounded-full flex-shrink-0">
                        <Bot className="w-4 h-4" />
                      </div>
                      <div className="chat-message-bot">
                        <p className="text-sm text-gray-800" data-testid={`bot-response-${msg.id}`}>
                          {msg.response}
                        </p>
                        <span className="text-xs text-gray-500 mt-2 block">
                          {new Date(msg.timestamp).toLocaleTimeString()}
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              ))
            )}

            {sendMessageMutation.isPending && (
              <div className="flex items-start space-x-3" data-testid="typing-indicator">
                <div className="bg-primary text-white p-2 rounded-full flex-shrink-0">
                  <Bot className="w-4 h-4" />
                </div>
                <div className="chat-message-bot">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  </div>
                </div>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </CardContent>
          
          {/* Chat Input */}
          <div className="p-4 border-t border-gray-200">
            <div className="flex space-x-2">
              <Input
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder={
                  language === 'hi' ? "यहां अपना कानूनी प्रश्न टाइप करें..."
                  : language === 'mr' ? "तुमचा कायदेशीर प्रश्न येथे टाइप करा..."
                  : "Type your legal question here..."
                }
                className="flex-1"
                disabled={sendMessageMutation.isPending}
                data-testid="chat-input"
              />
              <Button
                onClick={handleSendMessage}
                disabled={!message.trim() || !currentSessionId || sendMessageMutation.isPending}
                className="bg-primary text-white hover:bg-primary-dark"
                data-testid="send-button"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </Card>
      </div>
      
      {/* Quick Actions Sidebar */}
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-gray-900">
              {language === 'hi' ? "त्वरित कार्य"
               : language === 'mr' ? "द्रुत कृती"
               : "Quick Actions"}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {quickActions.map((action, index) => (
              <button
                key={index}
                className="quick-action-btn"
                data-testid={`quick-action-${index}`}
              >
                <div className="flex items-center space-x-3">
                  <action.icon className="text-primary w-5 h-5" />
                  <div>
                    <p className="font-medium text-sm">{action.title}</p>
                    <p className="text-xs text-gray-500">{action.subtitle}</p>
                  </div>
                </div>
              </button>
            ))}
          </CardContent>
        </Card>
        
        {/* Recent Updates */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-gray-900">
              {language === 'hi' ? "हाल के कानूनी अपडेट"
               : language === 'mr' ? "अलीकडील कायदेशीर अपडेट"
               : "Recent Legal Updates"}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="p-3 bg-blue-50 rounded-lg" data-testid="update-1">
              <p className="text-sm font-medium text-blue-900">
                {language === 'hi' ? "नई डेटा सुरक्षा दिशानिर्देश"
                 : language === 'mr' ? "नवीन डेटा संरक्षण मार्गदर्शक तत्त्वे"
                 : "New Data Protection Guidelines"}
              </p>
              <p className="text-xs text-blue-700 mt-1">
                {language === 'hi' ? "अपडेटेड गोपनीयता नीति आवश्यकताएं"
                 : language === 'mr' ? "अपडेट केलेल्या गोपनीयता धोरण आवश्यकता"
                 : "Updated privacy policies requirements"}
              </p>
            </div>
            <div className="p-3 bg-green-50 rounded-lg" data-testid="update-2">
              <p className="text-sm font-medium text-green-900">
                {language === 'hi' ? "IT संशोधन अधिनियम अपडेट"
                 : language === 'mr' ? "IT दुरुस्ती कायदा अपडेट"
                 : "IT Amendment Act Updates"}
              </p>
              <p className="text-xs text-green-700 mt-1">
                {language === 'hi' ? "साइबर अपराध दंड में बदलाव"
                 : language === 'mr' ? "सायबर गुन्हे शिक्षेतील बदल"
                 : "Changes in cyber crime penalties"}
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
