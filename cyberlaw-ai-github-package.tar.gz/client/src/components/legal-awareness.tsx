import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Star, ArrowRight, Search } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

interface LegalAwarenessProps {
  language: string;
}

interface Article {
  id: string;
  category: string;
  title: string;
  summary: string;
  readTime: string;
}

interface QuickRef {
  section: string;
  description: string;
}

interface LegalContent {
  featured: {
    title: string;
    description: string;
  };
  articles: Article[];
  quickRefs: QuickRef[];
}

export default function LegalAwareness({ language }: LegalAwarenessProps) {
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");

  const { data: content, isLoading } = useQuery<LegalContent>({
    queryKey: ["/api/legal-content", { language, category: selectedCategory }],
  });

  const categories = [
    { id: "all", 
      label: language === 'hi' ? "सभी विषय" 
             : language === 'mr' ? "सर्व विषय" 
             : "All Topics" 
    },
    { id: "cyber_crime", 
      label: language === 'hi' ? "साइबर अपराध कानून" 
             : language === 'mr' ? "सायबर गुन्हे कायदे" 
             : "Cyber Crime Laws" 
    },
    { id: "data_protection", 
      label: language === 'hi' ? "डेटा सुरक्षा" 
             : language === 'mr' ? "डेटा संरक्षण" 
             : "Data Protection" 
    },
    { id: "digital_rights", 
      label: language === 'hi' ? "डिजिटल अधिकार" 
             : language === 'mr' ? "डिजिटल हक्क" 
             : "Digital Rights" 
    },
    { id: "online_safety", 
      label: language === 'hi' ? "ऑनलाइन सुरक्षा" 
             : language === 'mr' ? "ऑनलाइन सुरक्षा" 
             : "Online Safety" 
    },
    { id: "financial_fraud", 
      label: language === 'hi' ? "वित्तीय धोखाधड़ी" 
             : language === 'mr' ? "आर्थिक फसवणूक" 
             : "Financial Fraud" 
    },
  ];

  const getCategoryColor = (category: string) => {
    const colors = {
      cyber_crime: "bg-blue-100 text-blue-800",
      privacy: "bg-green-100 text-green-800",
      financial: "bg-red-100 text-red-800",
      digital_rights: "bg-purple-100 text-purple-800",
    };
    return colors[category as keyof typeof colors] || "bg-gray-100 text-gray-800";
  };

  const filteredArticles = content?.articles?.filter(article => {
    const matchesCategory = selectedCategory === "all" || article.category === selectedCategory;
    const matchesSearch = !searchTerm || 
      article.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      article.summary.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  }) || [];

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64" data-testid="loading-legal-content">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-2" data-testid="awareness-title">
          {language === 'hi' ? "कानूनी जागरूकता केंद्र"
           : language === 'mr' ? "कायदेशीर जागरूकता केंद्र"
           : "Legal Awareness Center"}
        </h2>
        <p className="text-gray-600">
          {language === 'hi' ? "साइबर कानून, डिजिटल अधिकार और ऑनलाइन सुरक्षा उपायों के बारे में जानकारी रखें।"
           : language === 'mr' ? "सायबर कायदे, डिजिटल हक्क आणि ऑनलाइन सुरक्षा उपायांबद्दल माहिती ठेवा."
           : "Stay informed about cyber laws, digital rights, and online safety measures."}
        </p>
      </div>

      {/* Search Bar */}
      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder={
              language === 'hi' ? "कानूनी विषयों की खोज करें..."
              : language === 'mr' ? "कायदेशीर विषयांचा शोध घ्या..."
              : "Search legal topics..."
            }
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
            data-testid="search-input"
          />
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-8">
        {/* Category Filters */}
        <div className="lg:col-span-1">
          <Card className="sticky top-24" data-testid="category-filters">
            <CardHeader>
              <CardTitle className="font-semibold text-gray-900 mb-4">
                {language === 'hi' ? "श्रेणियां"
                 : language === 'mr' ? "श्रेणी"
                 : "Categories"}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {categories.map((category) => (
                <button
                  key={category.id}
                  className={`category-filter-btn ${
                    selectedCategory === category.id ? 'active' : ''
                  }`}
                  onClick={() => setSelectedCategory(category.id)}
                  data-testid={`category-${category.id}`}
                >
                  {category.label}
                </button>
              ))}
            </CardContent>
          </Card>
        </div>
        
        {/* Content Area */}
        <div className="lg:col-span-3 space-y-6">
          {/* Featured Article */}
          {content?.featured && (
            <Card className="bg-gradient-to-r from-primary to-primary-dark text-white" data-testid="featured-article">
              <CardContent className="p-8">
                <div className="flex items-center space-x-2 mb-3">
                  <Star className="w-4 h-4" />
                  <span className="text-sm font-medium opacity-90">
                    {language === 'hi' ? "विशेष विषय"
                     : language === 'mr' ? "वैशिष्ट्यीकृत विषय"
                     : "Featured Topic"}
                  </span>
                </div>
                <h2 className="text-2xl font-bold mb-3">{content.featured.title}</h2>
                <p className="opacity-90 mb-4">{content.featured.description}</p>
                <Button className="bg-white text-primary hover:bg-gray-100" data-testid="read-featured">
                  {language === 'hi' ? "और पढ़ें"
                   : language === 'mr' ? "अधिक वाचा"
                   : "Read More"} 
                  <ArrowRight className="w-4 h-4 ml-1" />
                </Button>
              </CardContent>
            </Card>
          )}
          
          {/* Articles Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredArticles.map((article) => (
              <Card key={article.id} className="legal-card" data-testid={`article-${article.id}`}>
                <CardContent>
                  <div className="flex items-center space-x-2 mb-3">
                    <Badge className={getCategoryColor(article.category)}>
                      {article.category.replace('_', ' ')}
                    </Badge>
                    <span className="text-xs text-gray-500">{article.readTime}</span>
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">
                    {article.title}
                  </h3>
                  <p className="text-gray-600 text-sm mb-4">
                    {article.summary}
                  </p>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-gray-500">
                      {language === 'hi' ? "अपडेट किया गया: दिसंबर 15, 2024"
                       : language === 'mr' ? "अपडेट केले: डिसेंबर 15, 2024"
                       : "Updated: Dec 15, 2024"}
                    </span>
                    <Button variant="link" className="text-primary text-sm font-medium p-0" data-testid={`read-article-${article.id}`}>
                      {language === 'hi' ? "लेख पढ़ें"
                       : language === 'mr' ? "लेख वाचा"
                       : "Read Article"}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredArticles.length === 0 && (
            <div className="text-center py-8" data-testid="no-articles">
              <p className="text-gray-500">
                {language === 'hi' ? "कोई लेख नहीं मिला।"
                 : language === 'mr' ? "कोणते लेख सापडले नाहीत."
                 : "No articles found."}
              </p>
            </div>
          )}
          
          {/* Quick Reference Cards */}
          {content?.quickRefs && content.quickRefs.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-semibold text-gray-900">
                  {language === 'hi' ? "त्वरित कानूनी संदर्भ"
                   : language === 'mr' ? "द्रुत कायदेशीर संदर्भ"
                   : "Quick Legal References"}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {content.quickRefs.map((ref, index) => (
                    <div key={index} className="p-4 bg-blue-50 rounded-lg" data-testid={`quick-ref-${index}`}>
                      <h4 className="font-medium text-blue-900 mb-2">{ref.section}</h4>
                      <p className="text-sm text-blue-700">{ref.description}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
