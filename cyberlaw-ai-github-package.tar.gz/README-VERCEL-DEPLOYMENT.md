# Deploying CyberLaw AI to Vercel

This guide will help you deploy your CyberLaw AI application to Vercel.

## Prerequisites

1. **GitHub Account**: Your code needs to be in a GitHub repository
2. **Vercel Account**: Sign up at [vercel.com](https://vercel.com)
3. **Environment Variables**: You'll need your API keys

## Step 1: Prepare Your Code

1. **Create a GitHub Repository**:
   - Go to GitHub and create a new repository
   - Clone this Replit project to your local machine or download the files
   - Push the code to your GitHub repository

2. **Required Files** (already created):
   - `vercel.json` - Vercel configuration
   - `api/index.js` - Serverless function entry point
   - `README-VERCEL-DEPLOYMENT.md` - This guide

## Step 2: Environment Variables Setup

You'll need to set these environment variables in Vercel:

### Required:
- `GEMINI_API_KEY` - Your Google Gemini API key (for AI functionality)

### Optional (if you want to use OpenAI instead):
- `OPENAI_API_KEY` - Your OpenAI API key

### How to get API keys:

**For Gemini API Key:**
1. Go to [Google AI Studio](https://makersuite.google.com/app/apikey)
2. Create a new API key
3. Copy the key

## Step 3: Deploy to Vercel

1. **Connect to Vercel**:
   - Go to [vercel.com](https://vercel.com) and sign in
   - Click "New Project"
   - Import your GitHub repository

2. **Configure the Project**:
   - Framework Preset: Select "Other" or "Vite"
   - Root Directory: Leave as default (.)
   - Build Command: `npm run build`
   - Output Directory: `dist`

3. **Add Environment Variables**:
   - In the project settings, go to "Environment Variables"
   - Add your `GEMINI_API_KEY`
   - Add any other required keys

4. **Deploy**:
   - Click "Deploy"
   - Wait for the build to complete

## Step 4: Configure Custom Domain (Optional)

1. In your Vercel project dashboard, go to "Settings" > "Domains"
2. Add your custom domain
3. Follow Vercel's instructions to configure DNS

## Important Notes

### Limitations on Vercel:
- **File Storage**: Vercel doesn't support persistent file storage
- **Database**: Consider using Vercel's Postgres or external database
- **Serverless Functions**: Have a 10-second timeout limit
- **Memory**: Limited to 1GB for Hobby plan

### Recommended Upgrades for Production:
1. **Database**: Replace in-memory storage with:
   - Vercel Postgres
   - Supabase
   - PlanetScale
   - Neon

2. **File Storage**: For document uploads, use:
   - Vercel Blob
   - Cloudinary
   - AWS S3

3. **Session Storage**: Replace memory sessions with:
   - Redis (Upstash)
   - Database sessions

## Troubleshooting

### Common Issues:

1. **Build Fails**:
   - Check that all dependencies are in package.json
   - Ensure TypeScript compiles without errors

2. **API Routes Not Working**:
   - Verify vercel.json configuration
   - Check function timeout limits

3. **Environment Variables**:
   - Make sure all required keys are set
   - Redeploy after adding new variables

4. **File Upload Issues**:
   - Vercel has size limits for uploads
   - Consider using external storage

### Getting Help:
- Vercel Documentation: [vercel.com/docs](https://vercel.com/docs)
- Vercel Community: [github.com/vercel/vercel/discussions](https://github.com/vercel/vercel/discussions)

## Cost Considerations

- **Hobby Plan**: Free with limitations
- **Pro Plan**: $20/month for better limits
- **Enterprise**: Custom pricing

Monitor your usage in the Vercel dashboard to avoid unexpected charges.