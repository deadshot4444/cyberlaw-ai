import type { Express, Request } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import { storage } from "./storage";
import { getLegalAdvice, analyzeDocument } from "./services/gemini";
import { translationService } from "./services/translation";
import { ocrService } from "./services/ocr";
import { pdfGenerator } from "./services/pdfGenerator";
import { insertChatSessionSchema, insertChatMessageSchema, insertComplaintSchema } from "@shared/schema";
import { z } from "zod";

// Extend Express Request type for multer
interface MulterRequest extends Request {
  files?: Express.Multer.File[];
}

// Configure multer for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize OCR service
  await ocrService.initialize();

  // Chat endpoints
  app.post("/api/chat/session", async (req, res) => {
    try {
      const sessionData = insertChatSessionSchema.parse(req.body);
      const session = await storage.createChatSession(sessionData);
      res.json(session);
    } catch (error) {
      res.status(400).json({ 
        message: error instanceof Error ? error.message : "Failed to create chat session" 
      });
    }
  });

  app.get("/api/chat/session/:sessionId/messages", async (req, res) => {
    try {
      const { sessionId } = req.params;
      const messages = await storage.getChatMessages(sessionId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to get messages" 
      });
    }
  });

  app.post("/api/chat/message", async (req, res) => {
    try {
      const { sessionId, message, language = 'en' } = req.body;
      
      // Save user message
      const userMessage = await storage.addChatMessage({
        sessionId,
        message,
        response: null,
        isUser: true,
      });

      // Get conversation history
      const messages = await storage.getChatMessages(sessionId);
      const conversationHistory = messages
        .filter(m => m.response)
        .map(m => [
          { role: 'user' as const, content: m.message },
          { role: 'assistant' as const, content: m.response! }
        ]).flat();

      // Get AI response
      const aiResponse = await getLegalAdvice({
        message,
        language,
        conversationHistory,
      });

      // Save AI response
      const assistantMessage = await storage.addChatMessage({
        sessionId,
        message: JSON.stringify(aiResponse),
        response: aiResponse.response,
        isUser: false,
      });

      res.json({
        userMessage,
        assistantMessage,
        aiResponse,
      });
    } catch (error) {
      console.error('Chat error:', error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to process message" 
      });
    }
  });

  // Complaint endpoints
  app.post("/api/complaints", async (req, res) => {
    try {
      const complaintData = insertComplaintSchema.parse(req.body);
      const complaint = await storage.createComplaint(complaintData);
      
      // Generate PDF with proper date formatting
      const pdfData = {
        ...complaintData,
        incidentDate: new Date(complaintData.incidentDate).toLocaleDateString('en-IN'),
        evidence: Array.isArray(complaintData.evidence) ? complaintData.evidence : [],
      };
      const pdfContent = await pdfGenerator.generatePDF(pdfData);
      const pdfPath = `/api/complaints/${complaint.id}/pdf`;
      await storage.updateComplaintPdfPath(complaint.id, pdfPath);
      
      res.json({ ...complaint, pdfPath, pdfContent });
    } catch (error) {
      console.error('Complaint creation error:', error);
      res.status(400).json({ 
        message: error instanceof Error ? error.message : "Failed to create complaint" 
      });
    }
  });

  app.get("/api/complaints", async (req, res) => {
    try {
      const complaints = await storage.getComplaints();
      res.json(complaints);
    } catch (error) {
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to get complaints" 
      });
    }
  });

  app.get("/api/complaints/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const complaint = await storage.getComplaint(id);
      if (!complaint) {
        return res.status(404).json({ message: "Complaint not found" });
      }
      res.json(complaint);
    } catch (error) {
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to get complaint" 
      });
    }
  });

  app.get("/api/complaints/:id/pdf", async (req, res) => {
    try {
      const { id } = req.params;
      const complaint = await storage.getComplaint(id);
      if (!complaint) {
        return res.status(404).json({ message: "Complaint not found" });
      }
      
      const pdfData = {
        ...complaint,
        incidentDate: new Date(complaint.incidentDate).toLocaleDateString('en-IN'),
        evidence: Array.isArray(complaint.evidence) ? complaint.evidence : [],
      };
      const pdfContent = await pdfGenerator.generatePDF(pdfData);
      res.setHeader('Content-Type', 'text/html');
      res.setHeader('Content-Disposition', `attachment; filename="complaint-${id}.html"`);
      res.send(pdfContent);
    } catch (error) {
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to generate PDF" 
      });
    }
  });

  // Document upload and OCR endpoints
  app.post("/api/documents/upload", upload.array('documents'), async (req: MulterRequest, res) => {
    try {
      if (!req.files || !Array.isArray(req.files) || req.files.length === 0) {
        return res.status(400).json({ message: "No files uploaded" });
      }

      const results = [];
      
      for (const file of req.files) {
        try {
          // Extract text using OCR
          const ocrResult = await ocrService.extractFromBuffer(file.buffer, file.mimetype);
          
          // Analyze document
          const analysis = await analyzeDocument(ocrResult.text);
          
          // Save document
          const document = await storage.createDocument({
            filename: file.originalname,
            extractedText: ocrResult.text,
            analysis,
          });
          
          results.push({
            document,
            ocrResult,
            analysis,
          });
        } catch (error) {
          console.error(`Error processing file ${file.originalname}:`, error);
          results.push({
            filename: file.originalname,
            error: error instanceof Error ? error.message : "Processing failed",
          });
        }
      }
      
      res.json({ results });
    } catch (error) {
      console.error('Document upload error:', error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to process documents" 
      });
    }
  });

  app.get("/api/documents", async (req, res) => {
    try {
      const documents = await storage.getDocuments();
      res.json(documents);
    } catch (error) {
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to get documents" 
      });
    }
  });

  app.get("/api/documents/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const document = await storage.getDocument(id);
      if (!document) {
        return res.status(404).json({ message: "Document not found" });
      }
      res.json(document);
    } catch (error) {
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to get document" 
      });
    }
  });

  // Translation endpoint
  app.post("/api/translate", async (req, res) => {
    try {
      const { text, targetLanguage } = req.body;
      if (!text || !targetLanguage) {
        return res.status(400).json({ message: "Text and target language are required" });
      }
      
      const translatedText = await translationService.translate(text, targetLanguage);
      res.json({ translatedText });
    } catch (error) {
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Translation failed" 
      });
    }
  });

  // Legal awareness content endpoint
  app.get("/api/legal-content", async (req, res) => {
    try {
      const { category, language = 'en' } = req.query;
      
      // Static legal content for awareness
      const content = {
        featured: {
          title: language === 'hi' ? "IT संशोधन अधिनियम 2021 को समझना" 
                : language === 'mr' ? "IT दुरुस्ती कायदा 2021 समजून घेणे"
                : "Understanding the IT Amendment Act 2021",
          description: language === 'hi' ? "भारत के सूचना प्रौद्योगिकी अधिनियम में नवीनतम बदलावों के बारे में जानें"
                     : language === 'mr' ? "भारताच्या माहिती तंत्रज्ञान कायद्यातील नवीनतम बदलांबद्दल जाणून घ्या"
                     : "Learn about the latest changes in India's Information Technology Act",
        },
        articles: [
          {
            id: "1",
            category: "cyber_crime",
            title: language === 'hi' ? "यदि आप ऑनलाइन उत्पीड़न के शिकार हैं तो क्या करें"
                  : language === 'mr' ? "जर तुम्ही ऑनलाइन छळाचे बळी आहात तर काय करावे"
                  : "What to Do if You're a Victim of Online Harassment",
            summary: language === 'hi' ? "ऑनलाइन उत्पीड़न की रिपोर्ट करने, सबूत इकट्ठा करने और भारतीय साइबर कानून के तहत अपने कानूनी विकल्पों को समझने के लिए चरण-दर-चरण गाइड।"
                   : language === 'mr' ? "ऑनलाइन छळाचा अहवाल देणे, पुरावे गोळा करणे आणि भारतीय सायबर कायद्यांतर्गत तुमचे कायदेशीर पर्याय समजून घेण्यासाठी चरणबद्ध मार्गदर्शक।"
                   : "Step-by-step guide on reporting online harassment, collecting evidence, and understanding your legal options under Indian cyber law.",
            readTime: "5 min read",
          },
          {
            id: "2",
            category: "privacy",
            title: language === 'hi' ? "डेटा संरक्षण कानूनों के तहत आपके अधिकार"
                  : language === 'mr' ? "डेटा संरक्षण कायद्यांतर्गत तुमचे हक्क"
                  : "Your Rights Under Data Protection Laws",
            summary: language === 'hi' ? "अपने व्यक्तिगत डेटा अधिकारों को समझना, कंपनियां आपकी जानकारी का उपयोग कैसे कर सकती हैं, और अपनी डिजिटल गोपनीयता की सुरक्षा के लिए कदम।"
                   : language === 'mr' ? "तुमचे वैयक्तिक डेटा हक्क समजून घेणे, कंपन्या तुमची माहिती कशी वापरू शकतात आणि तुमची डिजिटल गोपनीयता संरक्षित करण्यासाठी पावले."
                   : "Understanding your personal data rights, how companies can use your information, and steps to protect your digital privacy.",
            readTime: "3 min read",
          }
        ],
        quickRefs: [
          {
            section: "IT Act Section 66A",
            description: language === 'hi' ? "संचार सेवा के माध्यम से आपत्तिजनक संदेश भेजने के लिए सजा"
                       : language === 'mr' ? "संवाद सेवेद्वारे आक्षेपार्ह संदेश पाठवण्यासाठी शिक्षा"
                       : "Punishment for sending offensive messages through communication service"
          },
          {
            section: "Section 66C",
            description: language === 'hi' ? "पहचान चोरी - इलेक्ट्रॉनिक हस्ताक्षर के धोखाधड़ी उपयोग के लिए सजा"
                       : language === 'mr' ? "ओळख चोरी - इलेक्ट्रॉनिक स्वाक्षरीच्या फसव्या वापरासाठी शिक्षा"
                       : "Identity theft - punishment for fraudulent use of electronic signature"
          }
        ]
      };
      
      res.json(content);
    } catch (error) {
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to get legal content" 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
