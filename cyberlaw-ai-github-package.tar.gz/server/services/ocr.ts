import { createWorker } from 'tesseract.js';
import fs from 'fs';
import path from 'path';

export interface OCRResult {
  text: string;
  confidence: number;
  language?: string;
}

export class OCRService {
  private worker: any;
  
  async initialize(): Promise<void> {
    this.worker = await createWorker('eng+hin');
  }
  
  async extractText(imagePath: string): Promise<OCRResult> {
    try {
      if (!this.worker) {
        await this.initialize();
      }
      
      const { data: { text, confidence } } = await this.worker.recognize(imagePath);
      
      return {
        text: text.trim(),
        confidence,
      };
    } catch (error) {
      console.error('OCR error:', error);
      throw new Error(`Failed to extract text: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
  
  async extractFromBuffer(buffer: Buffer, mimeType: string): Promise<OCRResult> {
    try {
      if (!this.worker) {
        await this.initialize();
      }
      
      const { data: { text, confidence } } = await this.worker.recognize(buffer);
      
      return {
        text: text.trim(),
        confidence,
      };
    } catch (error) {
      console.error('OCR buffer error:', error);
      throw new Error(`Failed to extract text from buffer: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
  
  async terminate(): Promise<void> {
    if (this.worker) {
      await this.worker.terminate();
    }
  }
}

export const ocrService = new OCRService();
