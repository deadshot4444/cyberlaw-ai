import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});

export interface LegalAdviceRequest {
  message: string;
  language: 'en' | 'hi' | 'mr';
  conversationHistory?: Array<{ role: 'user' | 'assistant'; content: string }>;
}

export interface LegalAdviceResponse {
  response: string;
  relevantSections?: string[];
  suggestedActions?: string[];
}

export async function getLegalAdvice(request: LegalAdviceRequest): Promise<LegalAdviceResponse> {
  try {
    const systemPrompt = getSystemPrompt(request.language);
    
    const messages: any[] = [
      { role: "system", content: systemPrompt },
      ...(request.conversationHistory || []),
      { role: "user", content: request.message }
    ];

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages,
      response_format: { type: "json_object" },
      temperature: 0.7,
      max_tokens: 1000,
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      response: result.response || "I apologize, but I couldn't generate a proper response. Please try again.",
      relevantSections: result.relevantSections || [],
      suggestedActions: result.suggestedActions || [],
    };
  } catch (error) {
    console.error('OpenAI API error:', error);
    throw new Error(`Failed to get legal advice: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

function getSystemPrompt(language: string): string {
  const prompts = {
    en: `You are an AI legal advisor specializing in Indian cyber law and Information Technology Act 2000. 
    Provide accurate, helpful legal guidance while emphasizing that this is general information and not a substitute for professional legal advice.
    
    Focus on:
    - Information Technology Act 2000 and amendments
    - Cyber crime laws in India
    - Data protection and privacy rights
    - Digital evidence and procedures
    - Complaint filing processes
    
    Always respond in JSON format with:
    {
      "response": "Your detailed legal advice",
      "relevantSections": ["List of relevant legal sections"],
      "suggestedActions": ["List of suggested immediate actions"]
    }`,
    
    hi: `आप भारतीय साइबर कानून और सूचना प्रौद्योगिकी अधिनियम 2000 में विशेषज्ञ एक AI कानूनी सलाहकार हैं।
    सटीक, सहायक कानूनी मार्गदर्शन प्रदान करें और यह स्पष्ट करें कि यह सामान्य जानकारी है और पेशेवर कानूनी सलाह का विकल्प नहीं है।
    
    फोकस करें:
    - सूचना प्रौद्योगिकी अधिनियम 2000 और संशोधन
    - भारत में साइबर क्राइम कानून
    - डेटा सुरक्षा और गोपनीयता अधिकार
    - डिजिटल साक्ष्य और प्रक्रियाएं
    - शिकायत दर्ज करने की प्रक्रिया
    
    हमेशा JSON फॉर्मेट में जवाब दें।`,
    
    mr: `तुम्ही भारतीय सायबर कायदा आणि माहिती तंत्रज्ञान कायदा 2000 मध्ये तज्ञ असलेले AI कायदेशीर सल्लागार आहात।
    अचूक, उपयुक्त कायदेशीर मार्गदर्शन प्रदान करा आणि स्पष्ट करा की ही सामान्य माहिती आहे आणि व्यावसायिक कायदेशीर सल्ल्याचा पर्याय नाही।
    
    लक्ष केंद्रित करा:
    - माहिती तंत्रज्ञान कायदा 2000 आणि दुरुस्त्या
    - भारतातील सायबर गुन्हे कायदे
    - डेटा संरक्षण आणि गोपनीयता हक्क
    - डिजिटल पुरावे आणि कार्यपद्धती
    - तक्रार नोंदवण्याची प्रक्रिया
    
    नेहमी JSON फॉर्मेटमध्ये उत्तर द्या।`
  };
  
  return prompts[language as keyof typeof prompts] || prompts.en;
}

export async function analyzeDocument(text: string, language: string = 'en'): Promise<any> {
  try {
    const prompt = `Analyze this legal document for cyber law relevance. Extract key legal terms, identify relevant sections of Indian cyber law, and provide a summary. Respond in JSON format.

Document text: ${text}`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
      temperature: 0.3,
    });

    return JSON.parse(response.choices[0].message.content || '{}');
  } catch (error) {
    console.error('Document analysis error:', error);
    throw new Error(`Failed to analyze document: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}
