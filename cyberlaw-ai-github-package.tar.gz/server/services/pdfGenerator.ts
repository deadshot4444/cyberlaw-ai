export interface ComplaintData {
  complaintType: string;
  incidentDate: string;
  complainantName: string;
  contactNumber: string;
  email: string;
  description: string;
  evidence?: any[];
}

export class PDFGeneratorService {
  generateComplaintHTML(data: ComplaintData): string {
    const currentDate = new Date().toLocaleDateString('en-IN');
    
    return `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Cyber Crime Complaint</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }
        .header { text-align: center; margin-bottom: 30px; }
        .title { font-size: 24px; font-weight: bold; margin-bottom: 10px; }
        .section { margin-bottom: 20px; }
        .label { font-weight: bold; }
        .value { margin-left: 20px; }
        .description { margin-top: 10px; padding: 15px; border: 1px solid #ccc; }
        .footer { margin-top: 40px; }
        .signature { margin-top: 60px; }
    </style>
</head>
<body>
    <div class="header">
        <div class="title">CYBER CRIME COMPLAINT</div>
        <div>As per Information Technology Act, 2000</div>
    </div>
    
    <div class="section">
        <div class="label">Date of Complaint:</div>
        <div class="value">${currentDate}</div>
    </div>
    
    <div class="section">
        <div class="label">Type of Complaint:</div>
        <div class="value">${data.complaintType}</div>
    </div>
    
    <div class="section">
        <div class="label">Date of Incident:</div>
        <div class="value">${new Date(data.incidentDate).toLocaleDateString('en-IN')}</div>
    </div>
    
    <div class="section">
        <div class="label">Complainant Details:</div>
        <div class="value">
            <div><strong>Name:</strong> ${data.complainantName}</div>
            <div><strong>Contact:</strong> ${data.contactNumber}</div>
            <div><strong>Email:</strong> ${data.email}</div>
        </div>
    </div>
    
    <div class="section">
        <div class="label">Detailed Description of Incident:</div>
        <div class="description">${data.description}</div>
    </div>
    
    ${data.evidence && data.evidence.length > 0 ? `
    <div class="section">
        <div class="label">Evidence Attached:</div>
        <div class="value">
            ${data.evidence.map((item, index) => `<div>${index + 1}. ${item.name || 'Evidence file'}</div>`).join('')}
        </div>
    </div>
    ` : ''}
    
    <div class="footer">
        <p><strong>Legal Notice:</strong> This complaint is filed under the relevant sections of the Information Technology Act, 2000, and other applicable cyber crime laws of India.</p>
        
        <p><strong>Declaration:</strong> I hereby declare that the information provided above is true and correct to the best of my knowledge and belief.</p>
        
        <div class="signature">
            <div>Complainant Signature: _________________</div>
            <div style="margin-top: 10px;">Date: ${currentDate}</div>
        </div>
    </div>
</body>
</html>
    `;
  }
  
  async generatePDF(data: ComplaintData): Promise<string> {
    // For now, return HTML content that can be converted to PDF client-side
    // In a real implementation, you would use a library like puppeteer or similar
    return this.generateComplaintHTML(data);
  }
}

export const pdfGenerator = new PDFGeneratorService();
