# Quick Vercel Deployment Guide

## 1. Setup GitHub Repository
1. Create a new repository on GitHub
2. Download/clone this Replit project
3. Push code to GitHub

## 2. Deploy to Vercel
1. Go to [vercel.com](https://vercel.com)
2. Click "New Project"
3. Import your GitHub repository
4. Use these settings:
   - Framework: Other/Vite
   - Build Command: `npm run build`
   - Output Directory: `dist`

## 3. Add Environment Variables
In Vercel project settings:
- `GEMINI_API_KEY` (required) - Get from [Google AI Studio](https://makersuite.google.com/app/apikey)

## 4. Deploy
Click Deploy and wait for completion.

## Important Notes
- File uploads are limited on Vercel free plan
- Consider upgrading to Pro for production use
- The app uses in-memory storage (data resets on deployment)

For production, consider:
- External database (Vercel Postgres, Supabase)
- File storage service (Vercel Blob, Cloudinary)
- Session storage (Redis/Upstash)