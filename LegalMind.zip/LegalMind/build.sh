#!/bin/bash

# Install dependencies
npm install

# Build the client
npm run build

# Create api directory for Vercel serverless functions
mkdir -p api
cp -r server/* api/

# Copy built client files to root for static serving
cp -r dist/* ./