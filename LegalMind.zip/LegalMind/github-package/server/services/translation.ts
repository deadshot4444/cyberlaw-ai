export interface TranslationService {
  translate(text: string, targetLanguage: string): Promise<string>;
  detectLanguage(text: string): Promise<string>;
}

// Basic translation mappings for common legal terms
const legalTermsTranslations = {
  en: {
    'cyberbullying': 'cyberbullying',
    'online_fraud': 'online fraud',
    'identity_theft': 'identity theft',
    'privacy_breach': 'privacy breach',
    'hacking': 'hacking',
    'file_complaint': 'file complaint',
    'legal_advice': 'legal advice',
    'cyber_crime': 'cyber crime'
  },
  hi: {
    'cyberbullying': 'साइबर बुलिंग',
    'online_fraud': 'ऑनलाइन धोखाधड़ी',
    'identity_theft': 'पहचान चोरी',
    'privacy_breach': 'गोपनीयता का उल्लंघन',
    'hacking': 'हैकिंग',
    'file_complaint': 'शिकायत दर्ज करें',
    'legal_advice': 'कानूनी सलाह',
    'cyber_crime': 'साइबर अपराध'
  },
  mr: {
    'cyberbullying': 'सायबर गुंडगिरी',
    'online_fraud': 'ऑनलाइन फसवणूक',
    'identity_theft': 'ओळख चोरी',
    'privacy_breach': 'गोपनीयतेचे उल्लंघन',
    'hacking': 'हॅकिंग',
    'file_complaint': 'तक्रार नोंदवा',
    'legal_advice': 'कायदेशीर सल्ला',
    'cyber_crime': 'सायबर गुन्हा'
  }
};

export class BasicTranslationService implements TranslationService {
  async translate(text: string, targetLanguage: string): Promise<string> {
    // Basic translation for legal terms
    const translations = legalTermsTranslations[targetLanguage as keyof typeof legalTermsTranslations];
    if (!translations) return text;
    
    let translatedText = text;
    Object.entries(legalTermsTranslations.en).forEach(([key, englishTerm]) => {
      const translatedTerm = translations[key as keyof typeof translations];
      if (translatedTerm) {
        translatedText = translatedText.replace(new RegExp(englishTerm, 'gi'), translatedTerm);
      }
    });
    
    return translatedText;
  }
  
  async detectLanguage(text: string): Promise<string> {
    // Basic language detection based on character sets
    if (/[\u0900-\u097F]/.test(text)) return 'hi'; // Devanagari script
    if (/[\u0900-\u097F]/.test(text)) return 'mr'; // Also uses Devanagari
    return 'en';
  }
}

export const translationService = new BasicTranslationService();
