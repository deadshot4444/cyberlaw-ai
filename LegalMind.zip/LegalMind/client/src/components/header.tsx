import { useState } from "react";
import { Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface HeaderProps {
  language: string;
  onLanguageChange: (language: string) => void;
}

export default function Header({ language, onLanguageChange }: HeaderProps) {
  return (
    <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Shield className="text-primary text-2xl" data-testid="logo-icon" />
              <span className="text-xl font-bold text-primary" data-testid="app-title">
                CyberLaw AI
              </span>
            </div>
            <span className="hidden sm:block text-sm text-gray-500 border-l pl-4">
              Legal Advisor Platform
            </span>
          </div>
          
          <div className="flex items-center space-x-4">
            <Select value={language} onValueChange={onLanguageChange}>
              <SelectTrigger className="w-32" data-testid="language-selector">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="en" data-testid="lang-en">🇺🇸 English</SelectItem>
                <SelectItem value="hi" data-testid="lang-hi">🇮🇳 हिंदी</SelectItem>
                <SelectItem value="mr" data-testid="lang-mr">🇮🇳 मराठी</SelectItem>
              </SelectContent>
            </Select>
            <Button className="bg-primary text-white hover:bg-primary-dark" data-testid="login-button">
              Login
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
