import { Shield } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <Shield className="text-2xl" />
              <span className="text-xl font-bold">CyberLaw AI</span>
            </div>
            <p className="text-gray-300 mb-4">
              AI-powered legal advisor platform specializing in cyber law and digital rights protection in India.
            </p>
            <div className="flex space-x-4">
              <button className="text-gray-400 hover:text-white" data-testid="social-twitter">
                <i className="fab fa-twitter"></i>
              </button>
              <button className="text-gray-400 hover:text-white" data-testid="social-linkedin">
                <i className="fab fa-linkedin"></i>
              </button>
              <button className="text-gray-400 hover:text-white" data-testid="social-facebook">
                <i className="fab fa-facebook"></i>
              </button>
            </div>
          </div>
          
          <div>
            <h3 className="font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2 text-sm text-gray-300">
              <li><a href="#" className="hover:text-white" data-testid="link-about">About Us</a></li>
              <li><a href="#" className="hover:text-white" data-testid="link-privacy">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-white" data-testid="link-terms">Terms of Service</a></li>
              <li><a href="#" className="hover:text-white" data-testid="link-support">Contact Support</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold mb-4">Emergency Contacts</h3>
            <ul className="space-y-2 text-sm text-gray-300">
              <li>Cyber Crime Helpline: <span className="text-white" data-testid="helpline-cyber">1930</span></li>
              <li>National Cyber Security: <span className="text-white" data-testid="helpline-security">1800-11-4949</span></li>
              <li>Women Helpline: <span className="text-white" data-testid="helpline-women">181</span></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-sm text-gray-400">
          <p data-testid="footer-disclaimer">
            &copy; 2024 CyberLaw AI. All rights reserved. This platform provides general legal information and should not replace professional legal advice.
          </p>
        </div>
      </div>
    </footer>
  );
}
