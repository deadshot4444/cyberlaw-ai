# Overview

CyberLaw AI is an AI-powered legal advisor platform specializing in cyber law and digital rights protection in India. The application provides a comprehensive suite of tools including an AI legal chatbot, complaint generation system, document analysis with OCR capabilities, and legal awareness resources. The platform supports multiple languages (English, Hindi, and Marathi) to serve a diverse user base across India.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The frontend is built using React with TypeScript and implements a single-page application (SPA) architecture. The UI leverages shadcn/ui components built on top of Radix UI primitives for accessibility and customization. The application uses Wouter for client-side routing and TanStack Query for efficient data fetching and state management. Tailwind CSS provides utility-first styling with custom design tokens for consistent theming across light and dark modes.

## Backend Architecture
The backend follows a REST API architecture using Express.js with TypeScript. The server implements middleware for request logging, error handling, and file upload capabilities using Multer. The application uses an in-memory storage implementation (MemStorage) that abstracts data operations through an IStorage interface, allowing for easy migration to persistent storage solutions later.

## Data Management
The application uses Drizzle ORM with PostgreSQL for database schema definition and migrations. Database schemas are defined in TypeScript with proper validation using Zod. The current implementation includes tables for users, chat sessions, messages, complaints, and documents. Data validation is handled consistently across the application using Zod schemas derived from the database models.

## AI Integration
The system integrates with OpenAI's GPT-4o model for legal advice generation and document analysis. The AI service is configured with specialized prompts for cyber law context and supports multilingual responses. The application implements conversation history management to maintain context across chat sessions.

## Document Processing
OCR functionality is implemented using Tesseract.js to extract text from uploaded images and documents. The system supports multiple languages (English and Indian languages) for text extraction. Document analysis combines OCR results with AI-powered content analysis to identify legal terms and provide relevant insights.

## Multilingual Support
The application provides comprehensive multilingual support for English, Hindi, and Marathi. Translation services include basic legal term mappings and language detection capabilities. The UI adapts dynamically based on the selected language, with all user-facing text properly localized.

## File Management
File uploads are handled through Multer with memory storage and size restrictions. The system processes various document types and generates PDF outputs for complaint forms. File processing includes validation, OCR text extraction, and metadata storage.

# External Dependencies

## Database Services
- **Neon Database**: PostgreSQL hosting service for production database storage
- **Drizzle ORM**: TypeScript ORM for database operations and schema management

## AI Services
- **OpenAI API**: GPT-4o model for legal advice generation and document analysis
- **Tesseract.js**: Client-side OCR library for text extraction from images

## UI Framework
- **shadcn/ui**: Component library built on Radix UI primitives
- **Radix UI**: Headless UI components for accessibility and customization
- **Tailwind CSS**: Utility-first CSS framework for styling

## State Management
- **TanStack Query**: Data fetching and caching library for API state management
- **React Hook Form**: Form state management with validation

## Development Tools
- **Vite**: Build tool and development server
- **TypeScript**: Type safety and development experience
- **ESBuild**: Fast JavaScript bundler for production builds

## File Processing
- **Multer**: Middleware for handling multipart/form-data file uploads
- **Date-fns**: Date manipulation and formatting utilities

## Session Management
- **Connect-pg-simple**: PostgreSQL session store for Express sessions

## Deployment
- **Replit**: Development and hosting environment with integrated tooling
- **Vercel**: Production deployment platform configured with vercel.json
- **GitHub**: Source code repository for Vercel deployment integration

### Vercel Deployment Setup
The project includes pre-configured files for Vercel deployment:
- `vercel.json` - Deployment configuration with serverless function setup
- `api/index.js` - Serverless function entry point for backend API
- `.vercelignore` - Files to exclude from deployment
- `DEPLOYMENT.md` - Quick deployment guide

**Environment Variables Required:**
- `GEMINI_API_KEY` - Google Gemini API key for AI functionality

**Deployment Process:**
1. Push code to GitHub repository
2. Connect repository to Vercel
3. Configure environment variables
4. Deploy with automatic build process

**Production Considerations:**
- Current in-memory storage resets on each deployment
- File uploads limited by Vercel serverless constraints
- Recommended upgrades: external database, persistent file storage, Redis sessions